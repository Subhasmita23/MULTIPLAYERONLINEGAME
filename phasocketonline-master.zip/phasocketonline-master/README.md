# Phasocketonline
A server and client for a multiplayer browser game. Server in node.js, game in javascript with phaser and using socket.io for websockets.

Example applications that use phasocketonline:
 - http://apocalypsechess.online

Build and use guide:

1. clone this repository / download and extract zip to destination of your choice
2. navigate to the directory in your terminal
3. type "npm install"
4. run index.js
5. navigate to localhost:3000 in your browser


